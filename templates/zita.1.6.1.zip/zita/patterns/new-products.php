<?php
/**
 * New Section
 * 
 * slug: new-products
 * title: New Products Section
 * categories: zita
 */

return array(
    'title'      =>__( 'New Products Section', 'zita' ),
    'categories' => array( 'zita' ),
    'content'    => '<!-- wp:woocommerce/product-new {"columns":4,"rows":2} /-->',
);